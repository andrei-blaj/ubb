numar par
de cuvinte
