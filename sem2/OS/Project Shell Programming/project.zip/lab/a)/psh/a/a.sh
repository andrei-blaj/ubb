primul cuvant
doua
cuinte
impar
