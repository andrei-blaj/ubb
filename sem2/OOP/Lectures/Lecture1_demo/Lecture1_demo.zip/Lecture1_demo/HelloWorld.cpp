//#include <iostream>
//#include <Windows.h>
//
//int main()
//{
//	system("color f4");
//
//	std::cout<<"Hello World!"<<std::endl;
//	
//	system("pause");
//	return 0;
//}